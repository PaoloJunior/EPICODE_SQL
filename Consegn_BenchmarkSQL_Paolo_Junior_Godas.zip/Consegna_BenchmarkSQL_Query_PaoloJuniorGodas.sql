/*ESERCIZIO BANCHMARK PER IL MODULO DI SQL:CREAZIONE DB, CREAZIONE TABELLE CON LE PROPRIE CARATTERISTICHE, POPOLAMENTO TABELLE*/
/*CREAZIONE DEL DATABASE*/
create database Toysgroup;

/*dopo aver creato il DB posso utlizzare il comando "Set as default schema" o utilizzare la funzione USE*/
USE Toysgroup;
CREATE TABLE Toysgroup.Product (
    ID_Prodotto INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Nome_Prodotto VARCHAR(25) NOT NULL,
    Fascia_eta VARCHAR(25),
    Prezzo_unitario DECIMAL(5 , 2 ),
    Disponibilita_Deposito INT
);
CREATE TABLE Toysgroup.Region (
    ID_Citta VARCHAR(6) NOT NULL PRIMARY KEY,
    Nome_Citta VARCHAR(30) NOT NULL,
    Nome_Regione VARCHAR(50) NOT NULL,
    Nome_Stato VARCHAR(40) NOT NULL,
    Nome_Continente VARCHAR(40) NOT NULL
);
CREATE TABLE Toysgroup.Sales (
    COD_Sales INT NOT NULL PRIMARY KEY,
    Data_vendita DATE NOT NULL,
    Data_consegna DATE NOT NULL,
    Numero_pezzi INT NOT NULL,
    Prezzo_unitario DECIMAL(5 , 2 ) NOT NULL,
    Totale_vendita DECIMAL(8 , 2 ),
    ID_Prodotto INT NOT NULL,
    ID_Citta VARCHAR(6) NOT NULL,
    Nome_Citta VARCHAR(30),
    FOREIGN KEY (ID_Prodotto)
        REFERENCES Product (ID_Prodotto),
    FOREIGN KEY (ID_Citta)
        REFERENCES Region (ID_Citta)
);


/*POPOLAMENTO DELLE TABELLE*/
/*POPOLAMENTO TABELLA Product*/
INSERT INTO Product (Nome_Prodotto, Fascia_eta, Prezzo_unitario, Disponibilita_deposito) VALUES
 ('Bambola di pezza', '0-2', 15.99, 2500),
 ('Macchina giocattolo', '2-4', 29.99, 1800),
 ('Set di blocchi colorati', '2-4', 19.95, 3200),
 ('Pista macchinine', '4-6', 45.50, 1500),
 ('Bambola principessa', '4-6', 39.90, 2800),
 ('Gioco di società', '6-9', 24.95, 4100),
 ('Puzzle animali', '6-9', 12.99, 3500),
 ('Libro da colorare', '0-2', 9.99, 5000),
 ('Peluche orso', '0-2', 14.95, 2100),
 ('Camion pompieri', '2-4', 22.50, 1900),
 ('Cucina giocattolo', '2-4', 35.99, 3800),
 ('Set di costruzioni', '4-6', 49.99, 1600),
 ('Barbie fashion', '4-6', 32.95, 2900),
 ('Gioco di carte', '6-9', 15.99, 4300),
 ('Lego', '6-9', 59.99, 1200),
 ('Trenino elettrico', '4-6', 44.50, 2700),
 ('Casa delle bambole', '4-6', 69.99, 1400),
 ('Macchinina radiocomandata', '6-9', 29.95, 3600),
 ('Microscopio giocattolo', '6-9', 34.99, 1300);
 
 /*POPOLAMENTO TABELLA Region*/
INSERT INTO Region (ID_Citta, Nome_Citta, Nome_Regione, Nome_Stato, Nome_Continente)
VALUES
('Rm0001', 'Roma', 'Lazio', 'Italia', 'Europa'),
('Mi0002', 'Milano', 'Lombardia', 'Italia', 'Europa'),
('Na0003', 'Napoli', 'Campania', 'Italia', 'Europa'),
('Pa0004', 'Palermo', 'Sicilia', 'Italia', 'Europa'),
('Fi0005', 'Firenze', 'Toscana', 'Italia', 'Europa'),
('To0006', 'Torino', 'Piemonte', 'Italia', 'Europa'),
('Ba0007', 'Bari', 'Puglia', 'Italia', 'Europa'),
('Ge0008', 'Genova', 'Liguria', 'Italia', 'Europa'),
('Bo0009', 'Bologna', 'Emilia-Romagna', 'Italia', 'Europa'),
('Ve0010', 'Venezia', 'Veneto', 'Italia', 'Europa'),
('Pa0011', 'Parigi', 'Ile-de-France', 'Francia', 'Europa'),
('Be0012', 'Berlino', 'Germania', 'Germania', 'Europa'),
('Ma0013', 'Madrid', 'Comunità di Madrid', 'Spagna', 'Europa'),
('Ba0014', 'Barcellona', 'Catalogna', 'Spagna', 'Europa'),
('Lo0015', 'Londra', 'Inghilterra', 'Regno Unito', 'Europa'),
('Am0016', 'Amsterdam', 'Olanda Settentrionale', 'Paesi Bassi', 'Europa'),
('Br0017', 'Bruxelles', 'Regione Capitale Bruxelles', 'Belgio', 'Europa'),
('Vi0018', 'Vienna', 'Vienna', 'Austria', 'Europa'),
('Wa0019', 'Varsavia', 'Masovia', 'Polonia', 'Europa'),
('Pr0020', 'Praga', 'Regione Capitale di Praga', 'Repubblica Ceca', 'Europa'),
('To0021', 'Tokyo', 'Regione del Kantō', 'Giappone', 'Asia'),
('Sh0022', 'Shanghai', 'Regione Orientale', 'Cina', 'Asia'),
('Be0023', 'Pechino', 'Regione del Nord', 'Cina', 'Asia'),
('Se0024', 'Seoul', 'Area metropolitana di Seul', 'Corea del Sud', 'Asia'),
('Ba0025', 'Bangkok', 'Regione di Bangkok', 'Thailandia', 'Asia'),
('Si0026', 'Singapore', 'Singapore', 'Singapore', 'Asia'),
('De0027', 'Delhi', 'Territorio della Capitale Nazionale di Delhi', 'India', 'Asia'),
('Mu0028', 'Mumbai', 'Maharashtra', 'India', 'Asia'),
('Ko0029', 'Kolkata', 'Bengala Occidentale', 'India', 'Asia'),
('Ne0030', 'New_York', 'Stato di New York', 'USA', 'America Settentrionale'),
('Lo0031', 'Los_Angeles', 'California', 'USA', 'America Settentrionale'),
('Ch0032', 'Chicago', 'Illinois', 'USA', 'America Settentrionale'),
('Ho0033', 'Houston', 'Texas', 'USA', 'America Settentrionale'),
('Ph0034', 'Philadelphia', 'Pennsylvania', 'USA', 'America Settentrionale'),
('Me0035', 'Città del Messico', 'Città del Messico', 'Messico', 'America Settentrionale'),
('Sa0036', 'San Paolo', 'San Paolo', 'Brasile', 'America Meridionale'),
('Ri0037', 'Rio de Janeiro', 'Rio de Janeiro', 'Brasile', "America del Sud "),
('Si0038', 'Sydney', 'Nuovo Galles del Sud', 'Australia', 'Oceania'),
('Me0039', 'Melbourne', 'Victoria', 'Australia', 'Oceania'),
('Br0040', 'Brisbane', 'Queensland', 'Australia', 'Oceania'),
('Pe0041', 'Perth', 'Australia Occidentale', 'Australia', 'Oceania'),
('Ad0042', 'Adelaide', 'Australia Meridionale', 'Australia', 'Oceania'),
('Au0043', 'Auckland', 'Isola del Nord', 'Nuova Zelanda', 'Oceania'),
('Ca0044', 'Il Cairo', 'Governatorato del Cairo', 'Egitto', 'Africa'),
('Jo0045', 'Johannesburg', 'Gauteng', 'Sudafrica', 'Africa'),
('Ki0046', 'Kinshasa', 'Kinshasa', 'Repubblica Democratica del Congo', 'Africa'),
('La0047', 'Lagos', 'Lagos', 'Nigeria', 'Africa'),
('Ca0048', 'Casablanca', 'Grande Casablanca', 'Marocco', 'Africa'),
('To0049', 'Toronto', 'Ontario', 'Canada', 'America Settentrionale');

/*POPOLAMENTO TABELLA Sales*/
INSERT INTO Sales (COD_Sales, Data_vendita, Data_consegna, Numero_Pezzi, Prezzo_unitario, Totale_vendita, ID_Prodotto, ID_Citta, Nome_Citta)
VALUES
('10073', '2023-09-20', '2023-11-01', 1200, 59.99, 71988.0000, 3, 'Rm0001', 'Roma'),
('10074', '2023-09-27', '2023-11-08', 1800, 34.99, 62982.00, 6, 'Mi0002', 'Milano'),
('10075', '2023-10-04', '2023-11-15', 1400, 29.99, 41986.00, 7, 'Na0003', 'Napoli'),
('10076', '2023-10-11', '2023-11-22', 1100, 12.99, 14289.00, 8, 'Pa0004', 'Palermo'),
('10077', '2023-10-18', '2023-11-29', 1700, 59.99, 101983.00, 9, 'Fi0005', 'Firenze'),
('10078', '2023-10-25', '2023-12-06', 1300, 34.99, 45987.00, 10, 'To0006', 'Torino'),
('10079', '2023-11-01', '2023-12-13', 1900, 29.99, 56981.00, 11, 'Ba0007', 'Bari'),
('10080', '2023-11-08', '2023-12-20', 1500, 12.99, 19485.00, 12, 'Ge0008', 'Genova'),
('10081', '2023-11-15', '2023-12-27', 1100, 59.99, 65989.00, 13, 'Bo0009', 'Bologna'),
('10082', '2023-11-22', '2024-01-03', 1700, 34.99, 59983.00, 14, 'Ve0010', 'Venezia'),
('10083', '2024-11-29', '2025-01-10', 1300, 29.99, 38987.00, 15, 'Pa0011', 'Parigi'),
('10084', '2024-12-06', '2025-01-17', 1900, 12.99, 24681.00, 16, 'Be0012', 'Berlino'),
('10085', '2024-12-13', '2025-01-24', 1500, 59.99, 89985.00, 17, 'Ma0013', 'Madrid'),
('10086', '2024-12-20', '2025-01-31', 1100, 34.99, 38989.00, 18, 'Ba0014', 'Barcellona'),
('10016', '2024-02-29', '2024-04-04', 1300, 19.95, 25935.00, 3, 'Ca0048', 'Casablanca'),
('10017', '2024-03-07', '2024-04-11', 1200, 35.99, 43188.00, 11, 'Fi0005', 'Firenze'),
('10018', '2024-03-14', '2024-04-18', 1900, 49.99, 94981.00, 12, 'To0006', 'Torino'),
('10019', '2024-03-21', '2024-04-25', 1600, 22.50, 36000.00, 10, 'Pa0004', 'Palermo'),
('10020', '2024-03-28', '2024-05-02', 1400, 15.99, 22386.00, 8, 'Ge0008', 'Genova'),
('10021', '2024-04-04', '2024-05-09', 1500, 39.90, 59850.00, 7, 'Fi0005', 'Firenze'),
('10022', '2024-04-11', '2024-05-16', 1700, 24.95, 42435.00, 6, 'To0006', 'Torino'),
('10023', '2024-04-18', '2024-05-23', 1100, 12.99, 14289.00, 7, 'Ba0007', 'Bari'),
('10024', '2024-04-25', '2024-06-06', 1800, 9.99, 17982.00, 8, 'Ge0008', 'Genova'),
('10025', '2024-05-02', '2024-06-13', 1200, 14.95, 17940.00, 9, 'Bo0009', 'Bologna'),
('10026', '2024-05-09', '2024-06-20', 1000, 35.99, 35990.00, 11, 'Pa0011', 'Parigi'),
('10027', '2024-05-16', '2024-06-27', 1400, 49.99, 70986.00, 12, 'To0006', 'Torino'),
('10028', '2024-05-23', '2024-07-04', 1600, 32.95, 52720.00, 13, 'Ma0013', 'Madrid'),
('10029', '2024-05-30', '2024-07-11', 1900, 15.99, 29981.00, 14, 'Ba0014', 'Barcellona'),
('10030', '2023-12-20', '2024-01-19', 1500, 59.99, 89985.00, 15, 'Lo0015', 'Londra'),
('10031', '2024-01-25', '2024-02-23', 1800, 34.99, 62982.00, 16, 'Am0016', 'Amsterdam'),
('10032', '2024-02-08', '2024-03-08', 1400, 29.99, 41986.00, 17, 'Br0017', 'Bruxelles'),
('10033', '2024-02-22', '2023-04-22', 1100, 12.99, 14289.00, 18, 'Vi0018', 'Vienna'),
('10034', '2024-03-07', '2023-04-04', 1600, 59.99, 95984.00, 19, 'Wa0019', 'Varsavia'),
('10035', '2024-03-21', '2024-04-20', 1200, 34.99, 41987.00, 17, 'Pr0020', 'Praga'),
('10036', '2024-04-04', '2024-05-03', 1900, 29.99, 56987.00, 12, 'To0021', 'Tokyo'),
('10037', '2024-04-11', '2024-05-10', 1500, 12.99, 19485.00, 2, 'Sh0022', 'Shanghai'),
('10038', '2025-04-18', '2025-05-17', 1100, 59.99, 65989.00, 13, 'Be0023', 'Pechino'),
('10039', '2025-04-25', '2025-05-24', 1800, 34.99, 62982.00, 4, 'Se0024', 'Seoul'),
('10040', '2025-05-02', '2025-06-01', 1400, 29.99, 41986.00, 2, 'Ba0025', 'Bangkok'),
('10041', '2025-05-09', '2025-06-08', 1000, 12.99, 12990.00, 16, 'Si0026', 'Singapore'),
('10042', '2025-05-16', '2025-06-15', 1500, 59.99, 89985.00, 17, 'De0027', 'Delhi'),
('10043', '2025-05-23', '2025-06-22', 1200, 34.99, 41988.00, 18, 'Mu0028', 'Mumbai'),
('10044', '2025-02-16', '2025-03-15', 1900, 19.95, 37915.00, 19, 'Ko0029', 'Kolkata'),
('10045', '2025-03-01', '2025-03-30', 1700, 49.99, 84983.00, 10, 'Ne0030', 'New_York'),
('10046', '2025-03-08', '2025-04-06', 1300, 32.95, 42735.00, 11, 'Lo0031', 'Los_Angeles'),
('10047', '2025-03-22', '2025-04-21', 1500, 15.99, 23985.00, 12, 'Ch0032', 'Chicago'),
('10048', '2025-04-05', '2025-05-04', 1100, 29.99, 32989.00, 13, 'Ho0033', 'Houston'),
('10049', '2025-04-12', '2025-05-11', 1800, 12.99, 23382.00, 4, 'Ph0034', 'Philadelphia'),
('10050', '2025-04-19', '2025-05-18', 1400, 59.99, 83980.00, 15, 'Me0035', 'Città del Messico'),
('10051', '2025-04-26', '2025-05-25', 1000, 34.99, 34994.00, 16, 'Sa0036', 'San Paolo'),
('10052', '2025-05-03', '2025-06-02', 1600, 29.99, 47988.00, 17, 'Ri0037', 'Rio de Janeiro'),
('10053', '2026-05-10', '2026-06-09', 1200, 12.99, 15581.00, 18, 'Si0038', 'Sydney'),
('10054', '2026-05-17', '2026-06-16', 1900, 59.99, 113985.00, 19, 'Me0039', 'Melbourne'),
('10055', '2026-05-24', '2026-07-03', 1500, 34.99, 52489.00, 2, 'Br0040', 'Brisbane'),
('10056', '2026-05-31', '2026-07-10', 1100, 29.99, 32982.00, 1, 'Pe0041', 'Perth'),
('10057', '2026-06-07', '2026-07-17', 1800, 12.99, 23387.00, 2, 'Ad0042', 'Adelaide'),
('10059', '2026-06-14', '2026-07-24', 1300, 59.99, 78981.00, 2, 'Au0043', 'Auckland'),
('10060', '2026-06-21', '2026-08-01', 1900, 34.99, 66985.00, 12, 'Ca0044', 'Il Cairo'),
('10061', '2026-06-28', '2026-08-08', 1500, 29.99, 44985.00, 15, 'Jo0045', 'Johannesburg'),
('10062', '2026-07-05', '2026-08-15', 1100, 12.99, 14289.00, 16, 'Ki0046', 'Kinshasa'),
('10063', '2026-07-12', '2026-08-22', 1700, 59.99, 101989.00, 13, 'La0047', 'Lagos'),
('10064', '2026-07-19', '2026-08-29', 1300, 34.99, 45983.00, 8, 'Ca0048', 'Casablanca'),
('10065', '2026-07-26', '2026-09-06', 1900, 29.99, 56987.00, 7, 'To0049', 'Toronto'),
('10066', '2024-08-02', '2024-09-13', 1500, 12.99, 19481.00, 8, 'Rm0001', 'Roma'),
('10067', '2024-08-09', '2024-09-20', 1100, 59.99, 65985.00, 9, 'Mi0002', 'Milano'),
('10068', '2024-08-16', '2024-09-27', 1700, 34.99, 59989.00, 3, 'Na0003', 'Napoli'),
('10069', '2024-08-23', '2024-10-04', 1300, 29.99, 38983.00, 1, 'Pa0004', 'Palermo'),
('10070', '2024-08-30', '2024-10-11', 1900, 12.99, 24687.00, 2, 'Fi0005', 'Firenze');

/*RICHIESTE SELECT*/
SELECT 
    COUNT(*) AS numero_righe,
    COUNT(DISTINCT product.ID_Prodotto) AS totale_ID
FROM
    Product;

/*2*/
SELECT 
    COUNT(*) AS numero_righe,
    COUNT(DISTINCT region.ID_Citta) AS totale_ID
FROM
    region;
SELECT 
    COUNT(*) AS numero_righe,
    COUNT(DISTINCT sales.COD_Sales) AS totale_COD
FROM
    sales;
/*Esporre elenco dei prodotti venduti e per ognuno di questi il fatturato totale per anno */
SELECT 
    product.nome_prodotto,
    YEAR(sales.data_vendita),
    SUM(sales.totale_vendita)
FROM
    Sales
        LEFT JOIN
    product ON sales.id_prodotto = product.id_prodotto
GROUP BY product.nome_prodotto , YEAR(sales.data_vendita)
ORDER BY 2 DESC , 3 DESC;

/*esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente*/
SELECT 
    YEAR(sales.data_vendita),
    region.Nome_Stato,
    SUM(sales.totale_vendita)
FROM
    sales
        LEFT JOIN
    region ON sales.id_citta = region.id_citta
GROUP BY nome_stato , YEAR(data_vendita)
ORDER BY 1 DESC , 3 DESC; 

/*identificare il prodotto piu richiesto dal mercato*/
/*metodo1*/
SELECT 
    product.fascia_eta,
    SUM(sales.Numero_pezzi) AS totale_pezzi_venduti
FROM
    sales
        LEFT JOIN
    product ON sales.id_prodotto = product.id_prodotto
GROUP BY 1
ORDER BY 2 DESC
LIMIT 1;
 
/*identificare i prodotti invenduti*/
SELECT DISTINCT
    product.Nome_prodotto, sales.cod_sales
FROM
    product
        LEFT JOIN
    sales ON product.id_prodotto = sales.id_prodotto
WHERE
    cod_sales IS NULL;

/*metodo2*/
SELECT DISTINCT
    product.Nome_prodotto
FROM
    product
WHERE
    product.id_prodotto NOT IN (SELECT 
            sales.id_prodotto
        FROM
            sales);

/*esporre l'elenco dei prodotti con la rispettiva ultima data di vendita*/
SELECT 
    product.nome_prodotto, MAX(sales.data_vendita)
FROM
    sales
        LEFT JOIN
    product ON sales.id_prodotto = product.id_prodotto
GROUP BY 1
ORDER BY 2 DESC;
 